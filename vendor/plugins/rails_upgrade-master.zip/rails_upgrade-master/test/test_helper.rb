require 'test/unit'

require 'rubygems'
require 'active_support'
require 'active_support/test_case'
